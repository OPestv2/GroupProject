<?php
defined('BASEPATH') OR exit('No direct script access allowed');
?>
<div class="col-md-8">
    <h1><?php echo $page; ?></h1>
    <div class="row">
        <div class="col-md-4">
            Będzie opis<br><br><br><br><br><br><br><br><br><br>
        </div>
    </div> 
</div>